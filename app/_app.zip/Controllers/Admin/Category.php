<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

use App\Models\CategoryModel;
use App\Models\SettingsModel;

class Category extends BaseController
{
    public function index()
    {
        $session = session();
        if ($session->has('user_id')  && session('account_type') == 'Admin') {
            if (!can_view('category')) {
                return redirect()->to('admin/permission-not-allowed');
            }
            $settingModel = new SettingsModel();
            $data['settings'] = $settingModel->getSettings();

            
            return view('category/category', $data);
        } else {
            return redirect()->to('admin/auth/login');
        }
    }
    public function list()
    {
        // Ensure session is started
        if (!session()->has('user_id') || session('account_type') != 'Admin') {
            return redirect()->to('admin/login'); // Redirect to login if session is not set
        }

        if (!can_view('category')) {
            $output = ['success' => false, "message" => "Permission not allowed"];
            return $this->response->setJSON($output);
        }

        $categoryModel = new CategoryModel();
        $categories = $categoryModel->getCategoriesWithSubCount();
        $output['data'] = [];


        foreach ($categories as $row) {
            $img = "<a href='" . base_url($row['category_img']) . "' target='_blank'>
                        <img class='media-object round-media' src='" . base_url($row['category_img']) . "' alt='image' style='height: 75px; width: 40%'>
                    </a>";
            $action = "<a data-tooltip='tooltip' title='Edit Category' href='" . base_url("admin/category/edit/{$row['id']}") . "' class='btn btn-primary-light btn-xs'>
                        <i class='fi fi-tr-customize-edit'></i>
                       </a> <a type='button' data-tooltip='tooltip' title='Delete Category' onclick='deletecategory(" . $row['id'] . ")' class='btn btn-danger-light btn-xs'><i class='fi fi-tr-trash-xmark'>  </i> </a>";

            $output['data'][] = [
                $row['id'],
                $row['category_name'],
                $img,
                $row['sub_count'],
                $action,
            ];
        }

        return $this->response->setJSON($output);
    }
    public function edit($id)
    {
        $session = session();
        if ($session->has('user_id') && session('account_type') == 'Admin') {
            if (!can_edit('category')) {
                $output = ['success' => false, "message" => "Permission not allowed"];
                return $this->response->setJSON($output);
            }
            $categoryModel = new CategoryModel();
            $category = $categoryModel->find($id);
            $settingModel = new SettingsModel();
            
            return view('category/editCategory', [
                'settings' => $settingModel->getSettings(),
                
                'category' => $category
            ]);
        } else {
            return redirect()->to('admin/auth/login');
        }
    }
    public function add()
    {
        $output = ['success' => false];
        // Ensure session is started
        if (!session()->has('user_id') || session('account_type') != 'Admin') {
            return redirect()->to('admin/login'); // Redirect to login if session is not set
        }
        if (!can_add('category')) {
            $output = ['success' => false, "message" => "Permission not allowed"];
            return $this->response->setJSON($output);
        }
        if ($this->settings['demo_mode']) {
            $output = ['success' => false, "message" => "Demo Mode! Permission not allowed"];
            return $this->response->setJSON($output);
        }
        // Get POST data
        $cat_name = $this->request->getPost('cat_name');
        $is_bestseller_category = $this->request->getPost('is_bestseller_category');
        $cat_img = $this->request->getPost('cat_img');

        // Validate and sanitize category name
        $cat_name = filter_var($cat_name, FILTER_SANITIZE_STRING);
        $cat_name = str_replace("'", "’", $cat_name); // Replace single quotes with right single quote

        // Generate the initial slug
        $slug_prev = str_replace(" ", "-", $cat_name);
        $slug = preg_replace('/[^A-Za-z0-9-]/', '', strtolower($slug_prev));
        $slug1 = $slug;

        // Load the database model for posts
        $categoryModel = new CategoryModel();

        // Check if slug is available, add suffix if needed
        $check = true;
        $x = 1;
        while ($check) {
            $duplicateSlug = $categoryModel->where('slug', $slug1)->countAllResults();

            if ($duplicateSlug > 0) {
                // If a duplicate slug is found, append a number to the slug
                $slug1 = $slug . $x;
            } else {
                // Slug is unique, break the loop
                $check = false;
            }
            $x++;
        }
        // Validate the image format
        if (strpos($cat_img, 'data:image') === 0) {
            list(, $cat_img) = explode(';', $cat_img);
            list(, $cat_img) = explode(',', $cat_img);
            $cat_img = base64_decode($cat_img);

            // Generate file path
            $db_file_path = 'uploads/category/thump_' . time() . '.webp';
            $a_file_path =FCPATH . $db_file_path;

            // Write image to file
            if (file_put_contents($a_file_path, $cat_img) !== false) {
                // Insert category into database
                $categoryModel = new CategoryModel();
                $data = [
                    'category_name' => $cat_name,
                    'is_bestseller_category' => $is_bestseller_category,
                    'category_img'  => $db_file_path,
                    'slug'  => $slug1,
                ];

                if ($categoryModel->insert($data)) {
                    $output['success'] = true;
                    $output['message'] = 'Category added successfully';

                } else {
                    // Handle database insertion error
                    $output['message'] = 'Database error occurred.';
                }
            } else {
                // Handle file write error
                $output['message'] = 'Failed to save image.';
            }
        } else {
            // Handle invalid image data
            $output['message'] = 'Invalid image format.';
        }

        return $this->response->setJSON($output);
    }

    public function delete()
    {
        $output = ['success' => false];
        // Ensure session is started
        if (!session()->has('user_id') || session('account_type') != 'Admin') {
            return redirect()->to('admin/login'); // Redirect to login if session is not set
        }
        if (!can_delete('category')) {
            $output = ['success' => false, "message" => "Permission not allowed"];
            return $this->response->setJSON($output);
        }
        if ($this->settings['demo_mode']) {
            $output = ['success' => false, "message" => "Demo Mode! Permission not allowed"];
            return $this->response->setJSON($output);
        }
        // Get POST data
        $cat_id = $this->request->getPost('cat_id');

        $categoryModel = new CategoryModel();

        if ($categoryModel->delete($cat_id)) {
            $output['success'] = true;
        } else {
            // Handle database insertion error
            $output['message'] = 'Database error occurred.';
        }



        return $this->response->setJSON($output);
    }

    public function update()
    {
        $output = ['success' => false];
        // Ensure session is started
        if (!session()->has('user_id') || session('account_type') != 'Admin') {
            return redirect()->to('admin/login'); // Redirect to login if session is not set
        }
        if (!can_edit('category')) {
            $output = ['success' => false, "message" => "Permission not allowed"];
            return $this->response->setJSON($output);
        }
        if ($this->settings['demo_mode']) {
            $output = ['success' => false, "message" => "Demo Mode! Permission not allowed"];
            return $this->response->setJSON($output);
        }
        // Get POST data
        $cat_name = $this->request->getPost('cat_name');
        $cat_id = $this->request->getPost('cat_id');
        $cat_img = $this->request->getPost('files');
        $is_bestseller_category = $this->request->getPost('is_bestseller_category');

        // Validate and sanitize category name
        $cat_name = filter_var($cat_name, FILTER_SANITIZE_STRING);

        if ($cat_img == "") {
            $data = [
                'category_name' => $cat_name,
                'is_bestseller_category' => $is_bestseller_category,
            ];
        } else {
            list(, $cat_img) = explode(';', $cat_img);
            list(, $cat_img) = explode(',', $cat_img);
            $cat_img = base64_decode($cat_img);

            // Generate file path
            $db_file_path = 'uploads/category/thump_' . time() . '.webp';
            $a_file_path =FCPATH . $db_file_path;
            file_put_contents($a_file_path, $cat_img);
            $data = [
                'category_name' => $cat_name,
                'category_img'  => $db_file_path,
                'is_bestseller_category' => $is_bestseller_category,

            ];
        }

        $categoryModel = new CategoryModel();


        if ($categoryModel->where('id', $cat_id)->set($data)->update()) {
            $output['success'] = true;
        } else {
            $output['message'] = 'Database error occurred.';
        }

        return $this->response->setJSON($output);
    }
    public function categoryOrder()
    {
        $session = session();
        if ($session->has('user_id') && session('account_type') == 'Admin') {
            if (!can_view('category-order')) {
                $output = ['success' => false, "message" => "Permission not allowed"];
                return $this->response->setJSON($output);
            }
            $categoryModel = new CategoryModel();
            $categories = $categoryModel->orderBy('row_order')->findAll();
            $settingModel = new SettingsModel();
            
            return view('category/categoryOrder', [
                'settings' => $settingModel->getSettings(),
                
                'categories' => $categories
            ]);
        } else {
            return redirect()->to('admin/auth/login');
        }
    }

    public function categoryOrderUpdate()
    {
        // Ensure session is started
        if (!session()->has('user_id') || session('account_type') != 'Admin') {
            return redirect()->to('admin/login'); // Redirect to login if session is not set
        }
        if (!can_edit('category-order')) {
            $output = ['success' => false, "message" => "Permission not allowed"];
            return $this->response->setJSON($output);
        }
        if ($this->settings['demo_mode']) {
            $output = ['success' => false, "message" => "Demo Mode! Permission not allowed"];
            return $this->response->setJSON($output);
        }
        $request = $this->request->getJSON();
        $order = $request->order;

        $category_model = new CategoryModel();

        foreach ($order as $index => $productId) {
            // Update the row_order field in the database based on the new order
            $category_model->update($productId, ['row_order' => $index + 1]);
        }

        return $this->response->setJSON(['success' => true, 'message' => 'Category order updated']);
    }
}
