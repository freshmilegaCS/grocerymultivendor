<footer class="main-footer">
    <strong>Copyright &copy; <?php echo date("Y")?>.</strong>
    <div class="d-none d-sm-inline-block">
        Developed By <a href="https://apksoftwaresolution.com" target="_blank"><b><?= $settings['business_name']?></b> </a>
    </div>
</footer>